#include <bits/stdc++.h>
using namespace std;

int main(){
    char c[10][10];
    cout << c[0] << " " << c << endl;
    cout << c[1] << endl;
}